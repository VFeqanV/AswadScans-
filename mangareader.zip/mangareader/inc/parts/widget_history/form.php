<?php defined("ABSPATH") || die("!"); ?>
<p>Title Widget: <input class="widefat" name="<?php echo $name_field_name; ?>" type="text" value="<?php echo esc_attr( $name );?>" /></p> 
